/**
 * Custom JS
 *
 * @package AcmeThemes
 * @subpackage Read More
 */
jQuery(document).ready(function($){

    /*search*/
    $('.search-icon-menu').click(function(){
        $('.menu-search-toggle').fadeToggle();
    });
    
    $(window).load(function () {
        /*parallax scolling*/
        $('a[href*="#"]').click(function(event){
            $('html, body').animate({
                scrollTop: $( $.attr(this, 'href') ).offset().top-$('.at-navbar').height()
            }, 1000);
            event.preventDefault();
        });
        /*bootstrap sroolpy*/
        $("body").scrollspy({target: ".navbar-fixed-top", offset: $('.at-navbar').height()+50 } );
    });

    function read_more_stickyMenu() {

        var scrollTop = $(window).scrollTop();
        $('.at-navbar-wrapper').height($('.at-navbar-wrapper').height());
        var offset = $('.top-header').height() + $('#navbar >.container').height() -2;
        if ( scrollTop > offset ) {
            $('.main-navigation ').addClass('navbar-fixed-top ');
            $('.sm-up-container').show();
        }
        else {
            $('.main-navigation ').removeClass('navbar-fixed-top ');
            $('.sm-up-container').hide();
        }
    }
    //What happen on window scroll
    read_more_stickyMenu();
    $(window).on("scroll", function (e) {
        setTimeout(function () {
            read_more_stickyMenu();
        }, 300)
    });
});