<?php
/**
 * Display Social Links
 *
 * @since Read More 1.0.0
 *
 * @param null
 * @return void
 *
 */

if ( !function_exists('read_more_social_links') ) :

    function read_more_social_links( ) {

        global $read_more_customizer_all_values;
        ?>
        <ul class="socials">
            <?php
            if ( !empty( $read_more_customizer_all_values['read-more-facebook-url'] ) ) { ?>
                <li class="facebook">
                    <a href="<?php echo esc_url( $read_more_customizer_all_values['read-more-facebook-url'] ); ?>" data-title="Facebook" target="_blank"><i class="fa fa-facebook"></i></a>
                </li>
            <?php }
            if ( !empty( $read_more_customizer_all_values['read-more-twitter-url'] ) ) { ?>
                <li class="twitter">
                    <a href="<?php echo esc_url( $read_more_customizer_all_values['read-more-twitter-url'] ); ?>" data-title="Twitter" target="_blank"><i class="fa fa-twitter"></i></a>
                </li>
            <?php }
            if ( !empty( $read_more_customizer_all_values['read-more-youtube-url'] ) ) { ?>
                <li class="youtube">
                    <a href="<?php echo esc_url( $read_more_customizer_all_values['read-more-youtube-url'] ); ?>" class="Youtube" data-title="Youtube" target="_blank"><i class="fa fa-youtube"></i></a>
                </li>
            <?php }
            if ( !empty( $read_more_customizer_all_values['read-more-google-plus-url'] ) ) {
                ?>
                <li class="google-plus">
                    <a href="<?php echo esc_url( $read_more_customizer_all_values['read-more-google-plus-url'] ); ?>" data-title="Google Plus" target="_blank"><i class="fa fa-google-plus"></i></a>
                </li>
                <?php
            }
            ?>
        </ul>
        <?php
    }
endif;
add_filter( 'read_more_action_social_links', 'read_more_social_links', 10 );