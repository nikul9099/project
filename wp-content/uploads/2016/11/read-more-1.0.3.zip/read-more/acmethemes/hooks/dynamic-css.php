<?php
/**
 * Dynamic css
 *
 * @since Read More 1.0.0
 *
 * @param null
 * @return null
 *
 */
if ( ! function_exists( 'read_more_dynamic_css' ) ) :

    function read_more_dynamic_css() {

        global $read_more_customizer_all_values;
        /*Color options */
        $read_more_primary_color = $read_more_customizer_all_values['read-more-primary-color'];
        $custom_css = '';
        /*color*/
        $custom_css .= "
            a:hover,
            a:active,
            a:focus,
            .btn-primary:hover,
            .wpcf7-form input.wpcf7-submit:hover,
            .widget li a:hover,
            .posted-on a:hover,
            .cat-links a:hover,
            .comments-link a:hover,
            article.post .entry-header .entry-title a:hover, 
            article.page .entry-header .entry-title a:hover,
            .edit-link a:hover,
            .tags-links a:hover,
            .byline a:hover,
            .nav-links a:hover,
             .primary-color,
             .page-numbers.current,
             #read-more-breadcrumbs .breadcrumb-container a:hover{
                color: {$read_more_primary_color};
            }";

        /*background color*/
        $custom_css .= "
            .navbar .navbar-toggle:hover,
            .comment-form .form-submit input,
            .read-more,
            .posts-navigation a,
            .post-navigation a 
            .btn-primary,
            .wpcf7-form input.wpcf7-submit,
            .breadcrumb,
            .top-header,
            .sm-up-container,
            .primary-bg-color{
                background-color: {$read_more_primary_color};
                color:#fff;
            }";

        /*borders*/
        $custom_css .= "
            .comment-form .form-submit input,
            .read-more,
            .btn-primary,
            .btn-primary:hover,
            .posts-navigation a,
            .post-navigation a 
            .at-btn-wrap .btn-primary,
            .wpcf7-form input.wpcf7-submit,
            .btn-icon-box{
                border: 1px solid {$read_more_primary_color};
            }";
        $custom_css .= "
            .blog article.sticky{
                border-top: 2px solid {$read_more_primary_color};
            }";
        $custom_css .= "
            .main-navigation .current_page_item,
            .main-navigation .current-menu-item,
            .main-navigation .active ,
            .main-navigation .navbar-nav >li:hover{
                border-bottom: 2px solid {$read_more_primary_color};
            }";

        $custom_css .= "
             .breadcrumb::after {
                border-left: 5px solid {$read_more_primary_color};
            }";

        /*special button*/
        $custom_css .= "
        .btn-icon-box .btn-data{
            background-color: {$read_more_primary_color};
        }";
        $custom_css .= "
        .btn-icon-box .btn-data::before
        {
           	border-color: {$read_more_primary_color} transparent {$read_more_primary_color} {$read_more_primary_color};
        }";
        $custom_css .= "
        .btn-icon-box .btn-data::after
        {
        	border-color: {$read_more_primary_color} {$read_more_primary_color} {$read_more_primary_color} transparent;
        }";
        $custom_css .= "
        .slider-content .btn-icon-box
        {
        border: 1px solid {$read_more_primary_color};
        }";

        /*custom css*/
        $read_more_custom_css = wp_strip_all_tags ( $read_more_customizer_all_values['read-more-custom-css'] );
        if ( ! empty( $read_more_custom_css ) ) {
            $custom_css .= $read_more_custom_css;
        }
        wp_add_inline_style( 'read-more-style', $custom_css );
    }
endif;
add_action( 'wp_enqueue_scripts', 'read_more_dynamic_css', 99 );