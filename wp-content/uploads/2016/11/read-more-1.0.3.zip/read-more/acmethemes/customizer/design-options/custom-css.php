<?php
/*adding sections for custom css options */
$wp_customize->add_section( 'read-more-design-custom-css-option', array(
    'priority'       => 60,
    'capability'     => 'edit_theme_options',
    'theme_supports' => '',
    'title'          => __( 'Custom CSS', 'read-more' ),
    'panel'          => 'read-more-design-panel'
) );

/*custom-css*/
$wp_customize->add_setting( 'read_more_theme_options[read-more-custom-css]', array(
    'capability'		=> 'edit_theme_options',
    'default'			=> $defaults['read-more-custom-css'],
    'sanitize_callback'    => 'wp_strip_all_tags'
) );
$wp_customize->add_control( 'read_more_theme_options[read-more-custom-css]', array(
    'label'		=> __( 'Custom CSS', 'read-more' ),
    'section'   => 'read-more-design-custom-css-option',
    'settings'  => 'read_more_theme_options[read-more-custom-css]',
    'type'	  	=> 'textarea',
    'priority'  => 2
) );