<?php
/*adding theme options panel*/
$wp_customize->add_panel( 'read-more-design-panel', array(
    'priority'       => 190,
    'capability'     => 'edit_theme_options',
    'theme_supports' => '',
    'title'          => __( 'Layout/Design Option', 'read-more' )
) );

/*
* file for front page hiding content
*/
require read_more_file_directory('acmethemes/customizer/design-options/front-page-content.php');

/*
* file for sidebar layout
*/
require read_more_file_directory('acmethemes/customizer/design-options/sidebar-layout.php');

/*
* file for blog layout
*/
require read_more_file_directory('acmethemes/customizer/design-options/author-archive.php');

/*
* file for author archive layout
*/
require read_more_file_directory('acmethemes/customizer/design-options/blog-layout.php');

/*
* file for color options
*/
require read_more_file_directory('acmethemes/customizer/design-options/colors-options.php');

/*
* file for background image layout
*/
require read_more_file_directory('acmethemes/customizer/design-options/background-image.php');

/*
* file for custom css
*/
require read_more_file_directory('acmethemes/customizer/design-options/custom-css.php');